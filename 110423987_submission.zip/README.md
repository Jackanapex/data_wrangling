# data_wrangling
A personal repository for data wrangling tasks

To initialize the project folder run the following in terminal:


python -m venv venv

source venv/bin/activate

pip install -r requirements.txt


Then you are ready to go